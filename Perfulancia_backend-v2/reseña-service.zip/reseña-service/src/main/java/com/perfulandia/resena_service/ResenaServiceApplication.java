package com.perfulandia.resena_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResenaServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResenaServiceApplication.class, args);
	}

}
